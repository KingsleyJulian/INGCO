-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2024 at 04:36 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ingco_exam`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `commenter_name` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `comment_id` varchar(255) NOT NULL,
  `post_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `commenter_name`, `comment`, `comment_id`, `post_id`) VALUES
(4, 'Lester Traje Francisco', 'aertdasf', 'dQqQsMUg', 'DSFASDF'),
(5, 'Lester Traje Francisco', 'newertest', 'dQqQsMUg', 'dfsfasdfadsf'),
(6, 'Lester Traje Francisco', 'So I was trying to do this.', 'dQqQsMUg', 'DSFASDF'),
(7, 'Lester Traje Francisco', 'teste', 'dQqQsMUg', 'DSFASDF'),
(8, 'Lester Traje Francisco', 'gfh', 'dQqQsMUg', 'dfsfasdfadsf'),
(9, 'Lester Traje Francisco', 'dfsadfads?\r\n', 'dQqQsMUg', 'dfsfasdfadsf'),
(10, 'Lester Traje Francisco', 'test', 'dQqQsMUg', 'GndMYrsS'),
(11, 'Lester Traje Francisco', 'het', 'dQqQsMUg', 'rOJyAmvj'),
(12, 'So Good', 'I am testing this out', '5WU7HqvJ', 'zzQZr9zE'),
(13, 'So Good', 'hello', '5WU7HqvJ', 'zzQZr9zE'),
(14, 'So Good', 'Hi!', '5WU7HqvJ', 'dfsfasdfadsf'),
(15, 'So Good', 'Can we be friends?', '5WU7HqvJ', 'DSFASDF');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `date_time` datetime NOT NULL,
  `content_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `author`, `uid`, `date_time`, `content_id`) VALUES
(1, 'test', 'dfadsfadsfadsfdsfdsfdsfdsf', 'EAFDSFDS', 'DFASDFADSF', '2024-01-15 11:43:27', 'DSFASDF'),
(2, 'tes2t', 'adsfadsfadsfdsfads', 'dfasdfasdfds', 'dfsdsfsdf', '2024-01-15 11:47:01', 'dfsfasdfadsf'),
(7, 'hey test me out ', 'ow realluy?\r\n', 'Lester Traje Francisco', 'dQqQsMUg', '2024-01-15 22:59:32', 'zzQZr9zE');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `profile` varchar(355) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `uid`, `profile`) VALUES
(1, 'Hello Lester', 'Administrator@gmail.com', 'gege123', 'dQqQsMUg', '65a54e71ab032_domenico-loia-hGV2TfOh0ns-unsplash.jpg'),
(6, 'So Good', 'lesterfrancisco25@yahoo.com', 'test', '5WU7HqvJ', '65a55009b0048_Digital Drivers License LTO ISSUED - FRONT.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
