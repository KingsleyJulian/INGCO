<?php
require 'db_connect.php';

$delete_id = $_POST['delete_id'];


$sql = "DELETE FROM posts WHERE content_id = '$delete_id'";
$conn->query($sql);
header('location:../posts.php?success-delete');

?>