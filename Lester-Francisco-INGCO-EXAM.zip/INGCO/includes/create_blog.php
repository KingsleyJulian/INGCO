<?php
require 'db_connect.php';

$title = $_POST['title'];
$content = $_POST['blog_content'];
$author = $_POST['author'];
$uid = $_POST['uid'];
$content_id = $_POST['content_id'];

$sql = "INSERT INTO posts (`title`, `content`, `author`, `uid`, `date_time`, `content_id`) VALUES ('$title','$content','$author','$uid',NOW(),'$content_id')";
$conn->query($sql);
header('location:../dashboard.php?post-success');

?>