<?php
require 'db_connect.php';

// Fetch posts ordered by time
$fetchPosts = "SELECT * FROM posts ORDER BY date_time DESC";
$result = $conn->query($fetchPosts);

// Check if there are posts
if ($result->num_rows > 0) {
    $posts = array();

    // Fetch posts and store them in an array
    while ($row = $result->fetch_assoc()) {
        $posts[] = array(
            'title' => $row['title'],
            'author' => $row['author'],
            'date_time' => $row['date_time'],
            'content' => $row['content'],
            'uid' => $row['uid'],
            'content_id' => $row['content_id']
        );
    }

    // Return posts as JSON
    echo json_encode($posts);
} else {
    // No posts available
    echo json_encode(array());
}

$conn->close();
?>
