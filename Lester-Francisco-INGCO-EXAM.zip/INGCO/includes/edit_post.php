<?php
require 'db_connect.php';
$title = mysqli_real_escape_string($conn, $_POST['editedTitle']);
$content = mysqli_real_escape_string($conn, $_POST['editedContent']);
$content_id = $_POST['postId'];


$sql = "UPDATE posts SET title='$title',content='$content' WHERE content_id = '$content_id' ";
$conn->query($sql);
header('location:../posts.php?success-edit');

?>