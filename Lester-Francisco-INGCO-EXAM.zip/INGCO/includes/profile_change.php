<?php
session_start();
require 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Update Name
    if (!empty($_POST["userName"])) {
        $newName = $_POST["userName"];
        $sql_update_name = "UPDATE user SET name = '$newName' WHERE uid = '{$_SESSION['ses_uid']}'";
        $conn->query($sql_update_name);
    }

    // Update Email
    if (!empty($_POST["email"])) {
        $newEmail = $_POST["email"];
        $sql_update_email = "UPDATE user SET email = '$newEmail' WHERE uid = '{$_SESSION['ses_uid']}'";
        $conn->query($sql_update_email);
    }

    // Update Password
    if (!empty($_POST["password"])) {
        // Hash the new password before storing it
        $newPassword = password_hash($_POST["password"], PASSWORD_DEFAULT);
        $sql_update_password = "UPDATE user SET password = '$newPassword' WHERE uid = '{$_SESSION['ses_uid']}'";
        $conn->query($sql_update_password);
    }

    // Check if a file was selected for upload
    if (isset($_FILES["profilePicture"]) && $_FILES["profilePicture"]["error"] == UPLOAD_ERR_OK) {
        // Define the upload directory
        $uploadDir = "../uploads/";

        // Get the uploaded file name
        $fileName = basename($_FILES["profilePicture"]["name"]);

        // Generate a unique name for the file to avoid overwriting existing files
        $uniqueName = uniqid() . "_" . $fileName;
        $sql_update_pic = "UPDATE user SET profile = '$uniqueName' WHERE uid = '{$_SESSION['ses_uid']}'";
        $conn->query($sql_update_pic);

        // Define the path where the file will be saved
        $uploadPath = $uploadDir . $uniqueName;

        // Move the uploaded file to the destination directory
        if (move_uploaded_file($_FILES["profilePicture"]["tmp_name"], $uploadPath)) {
            // Update the session variable with the new profile picture path
            $_SESSION["ses_profile"] = $uploadPath;
        } else {
            echo "Failed to upload the file.";
        }
    }

    // Redirect back to the profile update page or any other page
    header("Location: ../profile.php?success");
    exit();
}
?>
