<?php
require 'db_connect.php';
session_start();

$email_login = $_POST['email'];
$password_login = $_POST['pass'];

// Corrected SQL query
$sql = "SELECT * FROM user WHERE email = '$email_login' AND password = '$password_login'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();

    $fullname = $row["name"];
    $email = $row["email"];
    $password = $row["password"];
    $uid = $row["uid"];
    $profile = $row["profile"];

    if ($password_login == $password) {
        $_SESSION["ses_fullname"] = $fullname;
        $_SESSION["ses_email"] = $email;
        $_SESSION["ses_password"] = $password; 
        $_SESSION["ses_uid"] = $uid;
        $_SESSION["ses_profile"] = $profile;
        header('location:../dashboard.php?correct');
    } else {
        header('location:../index.php?incorrect-credentials');
        exit();
    }
} else {
    header('location:../index.php?incorrect-credentials');
    exit();
}
?>
