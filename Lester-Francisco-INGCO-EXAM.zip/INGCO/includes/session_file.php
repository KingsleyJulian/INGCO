<?php
  if (!isset($_SESSION['ses_email'])) {
    // Redirect the user to a login page or display an error message
    header("Location: index.php"); // Change 'login.php' to your actual login page
    exit();
  }

?>