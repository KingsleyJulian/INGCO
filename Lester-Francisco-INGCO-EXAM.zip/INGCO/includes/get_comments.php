<?php

require 'db_connect.php';

// Check if the post_id parameter is set in the GET request
if (isset($_GET['post_id'])) {
    $postId = $_GET['post_id'];

    // Fetch comments for the specified post_id
    $fetchComments = "SELECT * FROM comments WHERE post_id = '$postId'";
    $result = $conn->query($fetchComments);

    // Check if there are comments
    if ($result->num_rows > 0) {
        $comments = array();

        // Fetch comments and store them in an array
        while ($row = $result->fetch_assoc()) {
            $comments[] = array(
                'commenter_name' => $row['commenter_name'],
                'comment' => $row['comment']
            );
        }

        // Return comments as JSON
        echo json_encode($comments);
    } else {
        // No comments for the specified post_id
        echo json_encode(array());
    }
} else {
    // post_id parameter not provided
    echo json_encode(array());
}

$conn->close();

?>
