<?php

require 'db_connect.php';
$comment = mysqli_real_escape_string($conn, $_POST['comment']);
$commenter = $_POST['commenter'];
$commenter_id = $_POST['commenter_id'];
$post_id = $_POST['post_id'];

$insert = "INSERT INTO comments (`comment`,`commenter_name`,`comment_id`,`post_id`) VALUES ('$comment','$commenter','$commenter_id','$post_id')";

$conn->query($insert);
header('location:../dashboard.php?comment-success;');

?>