$(document).ready(function () {
    // Ajax request to fetch posts
    $.ajax({
        url: './includes/get_my_posts.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            console.log('Received Data:', data); // Log the received data
            // Process the fetched data
            displayPosts(data);
        },
        error: function (error) {
            console.log('Error fetching posts:', error);
        }
    });

    // Function to display posts
    function displayPosts(posts) {
        var postsContainer = $('#postHtml'); // Change this line to target the specific container

        // Check if there are no posts
        if (posts.length === 0) {
            postsContainer.html('<p>No posts available.</p>');
            return;
        }

        // Iterate through each post and create HTML elements
        posts.forEach(function (post) {
            // Unique id for each modal based on content_id
            var modalEditId = 'editPostModal-' + post.content_id;
            var modalDeleteId = 'deletePostModal-' + post.content_id;
            var modalViewId = 'viewPostModal-' + post.content_id; // Unique id for the view modal

            var postHtml = `
                <div>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">${post.author}</h6>
                        </div>
                        <div class="card-body">
                            <h4 class="m-0 font-weight-bold text-primary">${post.title}</h4>
                            <br>
                            <p class="m-0 font-weight-bold text-primary">${post.content}</p>
                            <br>
                            <h6 class="m-0 font-weight-bold text-primary">Posted Date: ${post.date_time}</h6>

                            <!-- Divider -->
                            <hr class="my-3">

                            <!-- View, Delete, and Edit buttons -->
                            <div class="mt-3 text-center">
                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#${modalViewId}">
                                    <i class="fas fa-glasses"></i> View
                                </button>
                                <button type="button" class="btn btn-danger ml-2" data-toggle="modal" data-target="#${modalDeleteId}">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                                <button type="button" class="btn btn-primary ml-2" data-toggle="modal" data-target="#${modalEditId}" onclick="setEditModal(${post.content_id})">
                                    <i class="fas fa-pencil-alt"></i> Edit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal for delete -->
                <div class="modal fade" id="${modalDeleteId}" tabindex="-1" role="dialog" aria-labelledby="${modalDeleteId}Label" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="${modalDeleteId}Label">Delete Post</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p>Are you sure you want to delete this post?</p>
                            
                                <form method="POST" action="includes/delete.php">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-danger ml-2" name="delete_id" value="${post.content_id}">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal for edit -->
                <div class="modal fade" id="${modalEditId}" tabindex="-1" role="dialog" aria-labelledby="${modalEditId}Label" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="${modalEditId}Label">Edit Post</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form method="POST" action="includes/edit_post.php">
                                    <label for="editedTitle">Title:</label>
                                    <input type="text" class="form-control" id="editedTitle" value="${post.title}" name="editedTitle">

                                    <label for="editedContent">Content:</label>
                                    <textarea class="form-control" id="editedContent" name="editedContent" rows="3">${post.content}</textarea>

                                    <input type="hidden" name="postId" value="${post.content_id}" id="editPostId">

                                    <button type="submit" class="btn btn-primary mt-3">Save Changes</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal for view -->
                <div class="modal fade" id="${modalViewId}" tabindex="-1" role="dialog" aria-labelledby="${modalViewId}Label" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="${modalViewId}Label">View Post</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                            <h6 class="m-0 font-weight-bold text-primary">Title: ${post.title}</h6>
                            <br>
                            <p class="m-0 font-weight-bold text-primary">Content: ${post.content}</p>
                            <br>
                            <h6 class="m-0 font-weight-bold text-primary">Author: ${post.author}</h6>
                            <h6 class="m-0 font-weight-bold text-primary">Posted Date: ${post.date_time}</h6>

                            </div>
                        </div>
                    </div>
                </div>
            `;
            // Append the post HTML to the container
            postsContainer.append(postHtml);

            // Fetch and display comments for the current post immediately after appending
            fetchAndDisplayComments(post.content_id);
        });

        // JavaScript functions for delete and view
        function deletePost(postId) {
            // Implement the logic to delete the post with the given ID
            console.log('Deleting post with ID:', postId);
        }

        function viewPost(postId) {
            // Implement the logic to view the post with the given ID
            console.log('Viewing post with ID:', postId);
        }

        // Function to set up the modal for editing
        function setEditModal(postId) {
            // Retrieve post data for the given ID (you may need an additional AJAX request)
            var postData; // Replace this with actual data retrieval

            // Populate the modal with post data
            $('#editedTitle').val(postData.title);
            $('#editedContent').val(postData.content);
            $('#editPostId').val(postId);

            // Show the modal
            $('#editPostModal').modal('show');
        }
    }
});
