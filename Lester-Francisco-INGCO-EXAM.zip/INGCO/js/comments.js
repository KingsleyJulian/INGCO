// Fetch and display comments for the given post_id
function fetchAndDisplayComments(postId) {
    console.log('Fetching comments for post ID:', postId);
    var commentsContainer = $('#comments-' + postId);

    // Ajax request to fetch comments for the specific post
    $.ajax({
        url: 'includes/get_comments.php',
        type: 'GET',
        data: { post_id: postId },
        dataType: 'json',
        success: function (comments) {
            // Process the fetched comments
            comments.forEach(function (comment) {
                var commentHtml = `
                    <div class="card mt-2">
                        <div class="card-body">
                            <h6 class="m-0 font-weight-bold" style="color:black;">${comment.commenter_name}</h6>
                            <p class="m-0 font-weight-bold text-primary">${comment.comment}</p>
                        </div>
                    </div>`;

                // Append the comment HTML to the container
                commentsContainer.append(commentHtml);
            });
        },
        error: function (xhr, status, error) {
            console.log('Error fetching comments:', xhr, status, error);
        }
    });
}
