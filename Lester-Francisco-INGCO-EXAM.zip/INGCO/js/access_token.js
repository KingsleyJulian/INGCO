
function generateRandomString(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let randomString = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        randomString += characters.charAt(randomIndex);
    }
    return randomString;
}

// Function to set the random value in the form input
function setRandomValue() {
    var randomValue = generateRandomString(8); // Adjust the length as needed
    document.getElementById('token').value = randomValue;
    console.log(randomValue);
}

// Set the random value on page load
setRandomValue();
