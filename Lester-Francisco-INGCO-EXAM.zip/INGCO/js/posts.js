$(document).ready(function () {
    // Ajax request to fetch posts
    $.ajax({
        url: './includes/get_posts.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            console.log('Received Data:', data); // Log the received data
            // Process the fetched data
            displayPosts(data);
        },
        error: function (error) {
            console.log('Error fetching posts:', error);
        }
    });

    // Function to display posts
    // Function to display posts
function displayPosts(posts) {
    var postsContainer = $('#postHtml'); // Change this line to target the specific container

    // Check if there are no posts
    if (posts.length === 0) {
        postsContainer.html('<p>No posts available.</p>');
        return;
    }

    // Iterate through each post and create HTML elements
    posts.forEach(function (post) {
        var sessionFullname = document.getElementById('sessionFullname').value;
        var sessionUID = document.getElementById('sessionUID').value;
        var postHtml = `
            <div>
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Author: ${post.author}</h6>
                        
                    </div>
                    <div class="card-body">
                        <h4 class="m-0 font-weight-bold text-primary">${post.title}</h4>
                        <br>
                        <p class="m-0 font-weight-bold text-primary">${post.content}</p><br>
                        <h6 class="m-0 font-weight-bold text-primary">Posted Date: ${post.date_time}</h6>

                        <!-- Divider -->
                        <hr class="my-3">
                        <div class="mt-3" id="comments-${post.content_id}"></div>
                        <!-- Comment Box -->
                        <div class="mt-3">
                            <form method="POST" action="includes/comment.php">
                                <label for="comment">Add a comment:</label>
                                <textarea class="form-control" id="comment" name="comment" rows="1"></textarea>
                                <input type="hidden" name="commenter" value="${sessionFullname}"/>                                
                                <input type="hidden" name="commenter_id" value="${sessionUID}"/>
                                <input type="hidden" name="post_id" value="${post.content_id}"/>
                                <button type="submit" class="btn btn-primary mt-2">Post Comment</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>`;

        // Append the post HTML to the container
        postsContainer.append(postHtml);

        // Fetch and display comments for the current post immediately after appending
        fetchAndDisplayComments(post.content_id);
    });
}

});
